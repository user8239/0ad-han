# Vox Populi (0.0.22.1)

## Gameplay Changes:
---
##### Incorporated several features of the Pro Balance Mod (by user1)
https://wildfiregames.com/forum/index.php?/topic/22798-pro-balance-modconcept-please-test/


#####Vision

Citizen-solider infantry base vision 50. (Maximum: 70)

Citizen-Soldier cavalry base vision 55. (Maximum: 75)

Champion infantry vision 75.

Champion cavalry & Infantry heroes' vision 85.

War elephants' vision & Cavalry heroes' vision 90.

Elephant heroes' vision 95.

All siege 90 vision except the Siege Tower's 100.

Healers & Women base vision 25. (Maximum:45)

Traders & Worker Elephants base vision 30. (Maximum: 50)

Fishing ships base vision 10. (Maximum: 30)

Merchant ships base vision 40. (Maximum: 50)

Fire ships base vision 40. (Maximum: 50)

Biremes and Triremes base vision 80. (Maximum: 90)

Quinqueremes vision 100.

#####Attack Ranges & Movement Speed
Archer units maxiumum attack range reduced by 4.
Archer units gain +10 attack range per phase, slinger units +6.

All units start with only 70% of original movement speed.
Town Phase gives +15%, City Phase +25%

Run speed adjusted to be reduced by same amount as Walk Speed.


#####Citizen Soldiers
Cavalry rework
NEW - Unit loot increases with rank.
Sword, spear and skirmisher cavalry have all been reworked.
Based on tests so far: Sword Cavalry > Spear Cavalry > Skirmisher Cavalry > Sword Cavalry
Ptolemiac camel units now inflict a 20% attack penalty on all cavalry (including allied) within a 40m range.
Spear Cavalry 2s attack rate, attack reworked to suit the new values.

NEW - Elite units' stats improved slightly.
Citizen-soldier archers' maximum movement speed increased to 10.
Citizen-soldier cavalry capture rate decreased to 1, increase of only 10% hp per rank (instead of 20%).

#####Champions
All cavalry champions' capture attack reduced to 4.
Archer champions' movement speed increased to 13.
Skirmisher Chariot champions now have 320HP and +2 pierce attack but require 2 population.

Spear Cavalry Champions retain the 1.25x counter vs. other cavalry, likewise the 2 second attack rate.

Gauls - Naked Fanatic pierce attack increased by 2.

#####Heroes
Carthage - Hamilcar's 2nd aura: As you all probably figured by now, Hamilcar is not a "useful" hero (giving only +15% speed compared to the attack bonuses of Marhabal & Hannibal)
Thus, a new aura has been created (based on historical facts) which decreases enemy mercenary attack values by 20%.

Persians - Darius I's movement speed bonus aura increased from 10% to 15%.

Romans - Scipio's aura range increased from 10 meters to 30.


#####Technologies

2 new technologies at the Civic Centre, affecting both movement speed and health respectively.
Artillery Instructors: Siege weapons cost 20% less wood
This technology now costs: 500 food, 250 stone, 250 metal instead of the original 500 metal.

Unlock Spies: All support units may now be bribed, not only traders.

Mounts: Unlock village phase cavalry, researchable for 100F 100W 50M at the Corral.
Mounts icon changed, now uses a portrait imported from Delenda Est.
2nd redundant tech replaced with an autoresearched one - at the cost of a warning message when using the Structure Tree


Domestic animals base train time doubled, added new technology "Husbandry" for -15% train time and moved Stockbreeding to the Town Phase with maintained -25%.
 
Carthage - Colonisation technology (500W 500M) now affects Civic Structures (Civil Centre, Temples, Houses) by reducing their cost instead of -25% build time.

Blacksmith features new Specialization technologies
Hero armor tech split up into mounted and infantry ones, now supersedes infantry and cavalry armor upgrades respectively.

Wall Tower technologies added, first may shoot arrows then bolts.

#####Structures
All civilizations have received a new animal trainable from the Corral, this new addition is the Chicken, for all civilisations.

#####Ships
The Ptolemaic Juggernaut now costs only 5 population instead of the original 8.

#####Siege
Siege Towers' maximum arrow limit increased to 15.
Several changes by @Grugnas incorporated.

#####Trade
Rebalanced

#####Support
Healers now cost 200 food.

## Installation Instructions:
---
Extract this zip file into the mods folder.

The correct folder depends on your operating system. 

### Windows
replace USERNAME with your windows login name.

##### Vista or newer
> C:\Users\USERNAME\Documents\My Games\0ad\mods\

##### XP / 2000
> C:\Documents and Settings\USERNAME\My Documents\My Games\0ad\mods\

### OS X
> ~/Library/Application\ Support/0ad/mods/
> Note: "~" is a shorthand for the current user directory.

### Linux
> ~/.local/share/0ad/mods/
> Note: "~" is a shorthand for the current user directory.

 from <https://trac.wildfiregames.com/wiki/GameDataPaths>